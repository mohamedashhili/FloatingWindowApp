package com.example.floatingwindow

import android.app.AlertDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ImageView
import androidx.core.app.NotificationCompat

class FloatingWindowService : Service() {

    private lateinit var windowManager: WindowManager
    private var floatingView: View? = null
    private var bubbleView: View? = null
    private var isMinimized = false

    // أقل وأكبر حجم مسموح للنافذة (بالبكسل)
    private val minWidthPx by lazy { (150 * resources.displayMetrics.density).toInt() }
    private val minHeightPx by lazy { (150 * resources.displayMetrics.density).toInt() }
    private val maxWidthPx by lazy { resources.displayMetrics.widthPixels }
    private val maxHeightPx by lazy { resources.displayMetrics.heightPixels }

    companion object {
        const val CHANNEL_ID = "floating_window_channel"
        const val NOTIFICATION_ID = 1
    }

    override fun onCreate() {
        super.onCreate()
        startForegroundServiceWithNotification()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showFloatingWindow()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ---------- إنشاء النافذة العائمة الرئيسية ----------
    private fun showFloatingWindow() {
        val inflater = LayoutInflater.from(this)
        floatingView = inflater.inflate(R.layout.floating_window, null)

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 100
        params.y = 200
        // عرض وارتفاع ابتدائي بالبكسل عشان التكبير/التصغير يشتغل صح
        params.width = (300 * resources.displayMetrics.density).toInt()
        params.height = WindowManager.LayoutParams.WRAP_CONTENT

        windowManager.addView(floatingView, params)

        // زر الإغلاق
        floatingView?.findViewById<ImageView>(R.id.btn_close)?.setOnClickListener {
            stopSelf()
        }

        // زر التصغير (يتحول لفقاعة صغيرة زي شات هيدز)
        floatingView?.findViewById<ImageView>(R.id.btn_minimize)?.setOnClickListener {
            minimizeToBubble()
        }

        // زر فتح تطبيق آخر
        floatingView?.findViewById<Button>(R.id.btn_open_app)?.setOnClickListener {
            showAppPicker()
        }

        // السحب والإفلات لكامل النافذة عن طريق الشريط العلوي
        val dragHandle = floatingView?.findViewById<View>(R.id.top_bar)
        dragHandle?.setOnTouchListener(object : View.OnTouchListener {
            var initialX = 0
            var initialY = 0
            var initialTouchX = 0f
            var initialTouchY = 0f

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = initialX + (event.rawX - initialTouchX).toInt()
                        params.y = initialY + (event.rawY - initialTouchY).toInt()
                        windowManager.updateViewLayout(floatingView, params)
                        return true
                    }
                }
                return false
            }
        })

        // مقبض تغيير الحجم بالزاوية
        val resizeHandle = floatingView?.findViewById<View>(R.id.resize_handle)
        resizeHandle?.setOnTouchListener(object : View.OnTouchListener {
            var initialWidth = 0
            var initialHeight = 0
            var initialTouchX = 0f
            var initialTouchY = 0f

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialWidth = params.width
                        initialHeight = if (params.height > 0) params.height else floatingView?.height ?: minHeightPx
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val newWidth = (initialWidth + (event.rawX - initialTouchX).toInt())
                            .coerceIn(minWidthPx, maxWidthPx)
                        val newHeight = (initialHeight + (event.rawY - initialTouchY).toInt())
                            .coerceIn(minHeightPx, maxHeightPx)
                        params.width = newWidth
                        params.height = newHeight
                        windowManager.updateViewLayout(floatingView, params)
                        return true
                    }
                }
                return false
            }
        })
    }

    // ---------- قائمة اختيار تطبيق لفتحه ----------
    private fun showAppPicker() {
        val pm = packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null)
        mainIntent.addCategory(Intent.CATEGORY_LAUNCHER)
        val resolveInfoList = pm.queryIntentActivities(mainIntent, PackageManager.MATCH_ALL)
            .sortedBy { it.loadLabel(pm).toString() }

        val appNames = resolveInfoList.map { it.loadLabel(pm).toString() }.toTypedArray()

        val dialogLayoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val builder = AlertDialog.Builder(this)
        builder.setTitle("اختر تطبيق")
        builder.setAdapter(ArrayAdapter(this, android.R.layout.simple_list_item_1, appNames)) { _, which ->
            val info = resolveInfoList[which]
            val launchIntent = pm.getLaunchIntentForPackage(info.activityInfo.packageName)
            launchIntent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (launchIntent != null) startActivity(launchIntent)
        }
        val dialog = builder.create()
        dialog.window?.setType(dialogLayoutFlag)
        dialog.show()
    }

    // ---------- تصغير النافذة إلى فقاعة دائرية صغيرة ----------
    private fun minimizeToBubble() {
        if (isMinimized) return
        isMinimized = true

        floatingView?.let { windowManager.removeView(it) }

        val inflater = LayoutInflater.from(this)
        bubbleView = inflater.inflate(R.layout.floating_bubble, null)

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 0
        params.y = 300

        windowManager.addView(bubbleView, params)

        // سحب الفقاعة
        bubbleView?.setOnTouchListener(object : View.OnTouchListener {
            var initialX = 0
            var initialY = 0
            var initialTouchX = 0f
            var initialTouchY = 0f
            var moved = false

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = initialX + (event.rawX - initialTouchX).toInt()
                        params.y = initialY + (event.rawY - initialTouchY).toInt()
                        windowManager.updateViewLayout(bubbleView, params)
                        moved = true
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) restoreFromBubble()
                        return true
                    }
                }
                return false
            }
        })
    }

    // ---------- الرجوع من الفقاعة إلى النافذة الكاملة ----------
    private fun restoreFromBubble() {
        isMinimized = false
        bubbleView?.let { windowManager.removeView(it) }
        showFloatingWindow()
    }

    private fun startForegroundServiceWithNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "النافذة العائمة",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("النافذة العائمة تعمل")
            .setContentText("اضغط لإدارة النافذة")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()

        startForeground(NOTIFICATION_ID, notification)
    }

    override fun onDestroy() {
        super.onDestroy()
        floatingView?.let { windowManager.removeView(it) }
        bubbleView?.let { windowManager.removeView(it) }
    }
}
